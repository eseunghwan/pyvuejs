# -*- coding: utf-8 -*-

if __name__ == "__main__":
    import os, sys
    from pyvuejs.server import Server

    Server(
        os.path.dirname(os.path.abspath(__file__))
    ).start(sys.argv[1], int(sys.argv[2]))
