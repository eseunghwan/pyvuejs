# -*- coding: utf-8 -*-

if __name__ == "__main__":
    import os, sys

    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    try:
        os.system("\"{0}\" -m pyvuejs {1}".format(sys.executable, " ".join(sys.argv[1:])))
    except KeyboardInterrupt:
        pass
