# -*- coding: utf-8 -*-

__package_type__ = "app"
