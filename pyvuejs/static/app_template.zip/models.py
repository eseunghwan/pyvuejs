# -*- coding: utf-8 -*-
from pyvuejs.models import Model
from pyvuejs.binder import model_variable, event, method

class model(Model):
    pass
